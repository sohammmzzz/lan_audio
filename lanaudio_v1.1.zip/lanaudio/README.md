# LAN-AUDIO

Everything playing on the host PC, streamed in sync to everyone in the room.
Every PC runs the same agent (`lanaudio serve`, keep that terminal open).

## Install (every PC)

    pip install numpy rich PyAudioWPatch        # then: python lanaudio.py ...
    # or: uv tool install .                      # then: lanaudio ...

Firewall (admin CMD, every PC):

    netsh advfirewall firewall add rule name="lanaudio TCP" dir=in action=allow protocol=TCP localport=47800
    netsh advfirewall firewall add rule name="lanaudio UDP" dir=in action=allow protocol=UDP localport=47801

## Host

    lanaudio group create office
    lanaudio group add office 172.17.54.20 --name Yashwanta   # prints + copies Yashwanta's token
    lanaudio room start office                                 # dashboard: [A] let in [D] deny [S] stop ALL [Q] detach
    lanaudio room start gaming                                 # several rooms at once is fine
    lanaudio room stop office                                  # stop one
    lanaudio room stop                                         # stop ALL rooms

Lost the token? `lanaudio group token office Yashwanta`. Revoke: `lanaudio group remove office Yashwanta`.
Wrong IP inside tokens (VPN/Docker adapters)? add `--host-ip <your real LAN IP>` to `group add` / `group token`.

## Member

    lanaudio token add LA1.xxxxxxxx...     # one time
    lanaudio groups                        # your groups, and which are live right now
    lanaudio join office                   # any time. If it isn't live yet, you're pulled in when it starts.
    lanaudio leave

No token? `lanaudio join <host-ip>` knocks; the host sees it live and presses A.
